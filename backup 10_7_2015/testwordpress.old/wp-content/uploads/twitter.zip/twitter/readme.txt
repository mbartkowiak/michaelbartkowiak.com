=== Twitter ===
Contributors: V.J.Catkick
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=2933164
Tags: twitter, sidebar
Requires at least: 2.5
Tested up to: 2.7
Stable tag: 4.3

Customizable twitter widget for your sidebar.

== Description ==

Twitter Widget displays your tweets on your sidebar. There's lots of switches to tuen on/off what you want to display.

== Installation ==

Place the widget_twitter_vjck.php file in your /wp-content/plugins/ directory
and activate through the administration panel, and then go to the widget panel and
drag it to where you would like to have it!

== Frequently Asked Questions ==


== Screenshots ==

1. This is what this looks like.
2. option panel

